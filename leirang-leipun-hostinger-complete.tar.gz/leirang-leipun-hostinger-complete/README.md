# Leirang Leipun - Hostinger Deployment Guide

## Overview
This is a complete deployment package for the Leirang Leipun giveaway game website.

## Prerequisites
- Hostinger hosting account with Node.js support (Node.js 18+)
- Database access (PostgreSQL recommended)
- Terminal/SSH access to your hosting server

## Quick Start Deployment

### 1. Upload Files
Upload all files from this package to your hosting directory via:
- File Manager in Hostinger control panel, OR
- FTP/SFTP client, OR
- Git if using version control

### 2. Install Dependencies
Connect to your hosting server terminal and run:
```bash
npm install
```

### 3. Configure Environment
1. Copy the environment template:
   ```bash
   cp .env.example .env
   ```

2. Edit the `.env` file with your actual values:
   ```bash
   DATABASE_URL=postgresql://username:password@host:port/database
   SESSION_SECRET=your-very-secure-random-string-here
   NODE_ENV=production
   PORT=3000
   ```

### 4. Set Up Database
Run the database migrations:
```bash
npm run db:push
```

### 5. Build the Application
```bash
npm run build
```

### 6. Start the Application
```bash
npm start
```

## File Structure
```
├── client/          # Frontend React application
├── server/          # Backend Express server
├── shared/          # Shared schemas and types
├── dist/            # Built application (created after build)
├── package.json     # Dependencies and scripts
├── .env.example     # Environment template
└── README.md        # This file
```

## Database Schema
The application automatically creates these tables:
- `users` - User account information
- `game_participants` - Game participation records with prizes

## Features
- ✅ Interactive 5x5 tap game
- ✅ Instagram integration
- ✅ Prize distribution system
- ✅ Admin dashboard (/admin)
- ✅ Sound effects
- ✅ Mobile-responsive design
- ✅ Production-ready build

## Admin Access
Access the admin dashboard at: `https://yourdomain.com/admin`

## Troubleshooting

### Common Issues:
1. **Database Connection Failed**
   - Check DATABASE_URL format
   - Ensure database server is accessible
   - Verify credentials

2. **Port Already in Use**
   - Change PORT in .env file
   - Or use Hostinger's assigned port

3. **Build Errors**
   - Ensure Node.js version is 18+
   - Clear node_modules and reinstall: `rm -rf node_modules && npm install`

4. **Static Files Not Loading**
   - Check file permissions
   - Ensure dist/ folder exists after build

### Support
For hosting-specific issues, contact Hostinger support.
For application issues, check server logs: `npm run dev` for development mode.

## Production Optimization
- Gzip compression enabled
- Static file caching
- Database connection pooling
- Session management with PostgreSQL
- Error handling and logging

## Security Notes
- Keep .env file secure (never commit to version control)
- Use strong SESSION_SECRET
- Regularly update dependencies
- Monitor server logs for unusual activity

---
Built with ❤️ for Leirang Leipun Instagram Giveaway
