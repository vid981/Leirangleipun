import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { soundManager } from "@/utils/sounds";

interface Prize {
  type: 'bouquet' | 'coupon100' | 'coupon10' | 'bomb';
  emoji: string;
  text: string;
  value: string | number;
}

interface GameState {
  tapsRemaining: number;
  prizes: Prize[];
  gameBoard: Prize[];
  gameActive: boolean;
  currentReward: Prize | null;
  revealedSquares: boolean[];
}

const PRIZES: Prize[] = [
  { type: 'bouquet', emoji: '🌸', text: 'Beautiful Bouquet!', value: 'bouquet' },
  { type: 'coupon100', emoji: '🎉', text: '₹100 Off Coupon!', value: 100 },
  ...Array(6).fill({ type: 'coupon10', emoji: '🎁', text: '₹10 Off Coupon!', value: 10 }),
  ...Array(17).fill({ type: 'bomb', emoji: '💣', text: 'Bomb!', value: 'bomb' })
];

function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export default function Game() {
  const [gameStarted, setGameStarted] = useState(false);
  const [instagramUsername, setInstagramUsername] = useState("");
  const [showRewardModal, setShowRewardModal] = useState(false);
  const [showResultModal, setShowResultModal] = useState(false);
  const [showPlayLimitModal, setShowPlayLimitModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [resultType, setResultType] = useState<'win' | 'lose'>('win');
  const [resultTitle, setResultTitle] = useState("");
  const [resultMessage, setResultMessage] = useState("");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [playLimitInfo, setPlayLimitInfo] = useState<{canPlay: boolean; playsRemaining: number; resetDate?: string} | null>(null);
  const { toast } = useToast();

  const [gameState, setGameState] = useState<GameState>({
    tapsRemaining: 10,
    prizes: [],
    gameBoard: [],
    gameActive: false,
    currentReward: null,
    revealedSquares: Array(25).fill(false)
  });

  const saveGameResultMutation = useMutation({
    mutationFn: async (data: {
      instagramUsername: string;
      gameResult: string;
      prizesWon: string;
      tapsUsed: number;
    }) => {
      const response = await apiRequest("POST", "/api/game-result", data);
      return response.json();
    },
    onSuccess: () => {
      console.log("Game result saved successfully");
    },
    onError: (error) => {
      console.error("Failed to save game result:", error);
      toast({
        title: "Error",
        description: "Failed to save game result. Please try again.",
        variant: "destructive",
      });
    },
  });

  const checkPlayLimitMutation = useMutation({
    mutationFn: async (username: string) => {
      const response = await apiRequest("GET", `/api/can-play/${username}`);
      return response.json();
    },
    onSuccess: (data) => {
      setPlayLimitInfo(data);
      if (data.canPlay) {
        // User can play, start the game
        initializeGame();
        setGameStarted(true);
      } else {
        // User has reached play limit
        setShowPlayLimitModal(true);
      }
    },
    onError: (error) => {
      console.error("Play limit check failed:", error);
      toast({
        title: "Error",
        description: "Failed to check play limits. Please try again.",
        variant: "destructive",
      });
    }
  });

  const startGame = () => {
    if (!instagramUsername.trim()) {
      toast({
        title: "Instagram Username Required",
        description: "Please enter your Instagram username to continue.",
        variant: "destructive",
      });
      return;
    }

    // Play button click sound
    soundManager.playButtonClick();
    // Check play limit first
    checkPlayLimitMutation.mutate(instagramUsername);
  };

  const initializeGame = () => {
    setGameState({
      tapsRemaining: 10,
      prizes: [],
      gameBoard: shuffleArray([...PRIZES]),
      gameActive: true,
      currentReward: null,
      revealedSquares: Array(25).fill(false)
    });
  };

  const handleSquareClick = (index: number) => {
    if (!gameState.gameActive || gameState.tapsRemaining <= 0 || gameState.revealedSquares[index]) {
      return;
    }

    // Play tap sound immediately
    soundManager.playTap();

    const prize = gameState.gameBoard[index];
    const newRevealedSquares = [...gameState.revealedSquares];
    newRevealedSquares[index] = true;

    setGameState(prev => ({
      ...prev,
      tapsRemaining: prev.tapsRemaining - 1,
      revealedSquares: newRevealedSquares
    }));

    // Play reveal sound after a short delay
    setTimeout(() => {
      soundManager.playReveal();
    }, 200);

    // Handle different prize types
    setTimeout(() => {
      if (prize.type === 'bomb') {
        // Game over - bomb hit
        soundManager.playBombHit();
        endGame('lose', 'Sorry, you lost!', 'You hit a bomb 💣 Better luck next time!');
      } else if (prize.type === 'bouquet') {
        // Instant win - bouquet found
        soundManager.playBouquetWin();
        const finalPrizes = [...gameState.prizes, prize];
        
        // Immediately save the game result with prizes
        saveGameResultMutation.mutate({
          instagramUsername,
          gameResult: 'win',
          prizesWon: JSON.stringify(finalPrizes),
          tapsUsed: 10 - gameState.tapsRemaining
        });

        setGameState(prev => ({
          ...prev,
          prizes: finalPrizes,
          gameActive: false
        }));
        
        // Show the result modal
        setResultType('win');
        setResultTitle('Congratulations! 🎉');
        setResultMessage('You found the bouquet! You win the grand prize!');
        setShowResultModal(true);
      } else {
        // Coupon found - show modal
        soundManager.playPrizeFound();
        setGameState(prev => ({
          ...prev,
          currentReward: prize
        }));
        setShowRewardModal(true);
      }
    }, 500);
  };

  const keepReward = () => {
    soundManager.playButtonClick();
    if (gameState.currentReward) {
      const finalPrizes = [...gameState.prizes, gameState.currentReward];
      
      // Immediately save the game result with prizes
      saveGameResultMutation.mutate({
        instagramUsername,
        gameResult: 'win',
        prizesWon: JSON.stringify(finalPrizes),
        tapsUsed: 10 - gameState.tapsRemaining
      });

      setGameState(prev => ({
        ...prev,
        prizes: finalPrizes,
        currentReward: null,
        gameActive: false
      }));
      setShowRewardModal(false);
      
      // Show the result modal
      setResultType('win');
      setResultTitle('Smart Choice! 🧠');
      setResultMessage('You kept your reward and played it safe!');
      setShowResultModal(true);
    }
  };

  const continueGame = () => {
    soundManager.playButtonClick();
    if (gameState.currentReward) {
      const finalPrizes = [...gameState.prizes, gameState.currentReward];
      setGameState(prev => ({
        ...prev,
        prizes: finalPrizes,
        currentReward: null
      }));
      setShowRewardModal(false);

      // Check if game should end due to no taps remaining
      if (gameState.tapsRemaining <= 0) {
        // Immediately save the game result with prizes
        saveGameResultMutation.mutate({
          instagramUsername,
          gameResult: 'win',
          prizesWon: JSON.stringify(finalPrizes),
          tapsUsed: 10 - gameState.tapsRemaining
        });

        // Show the result modal
        setResultType('win');
        setResultTitle('Game Complete! 🎊');
        setResultMessage('You used all your taps!');
        setShowResultModal(true);
        setGameState(prev => ({ ...prev, gameActive: false }));
      }
    }
  };

  const endGame = (type: 'win' | 'lose', title: string, message: string) => {
    setGameState(prev => ({ ...prev, gameActive: false }));
    setResultType(type);
    setResultTitle(title);
    setResultMessage(message);
    setShowResultModal(true);

    // For lose conditions, save the game result immediately
    if (type === 'lose') {
      saveGameResultMutation.mutate({
        instagramUsername,
        gameResult: 'lose',
        prizesWon: JSON.stringify([]),
        tapsUsed: 10 - gameState.tapsRemaining
      });
    }
  };

  const resetGame = () => {
    setShowResultModal(false);
    setShowRewardModal(false);
    setShowPlayLimitModal(false);
    setShowShareModal(false);
    setGameStarted(false);
    setInstagramUsername("");
    setGameState({
      tapsRemaining: 10,
      prizes: [],
      gameBoard: [],
      gameActive: false,
      currentReward: null,
      revealedSquares: Array(25).fill(false)
    });
  };

  // Social sharing functions
  const shareOnFacebook = () => {
    const url = window.location.href;
    const shareText = "🌸 Just played Leirang Leipun! Try to find the hidden bouquet and win amazing prizes! 🎁";
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(shareText)}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  const shareOnTwitter = () => {
    const url = window.location.href;
    const shareText = "🌸 Just played Leirang Leipun! Try to find the hidden bouquet and win amazing prizes! 🎁 #LeirangLeipun #Giveaway";
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank', 'width=600,height=400');
  };

  const shareOnWhatsApp = () => {
    const url = window.location.href;
    const shareText = `🌸 Just played Leirang Leipun! Try to find the hidden bouquet and win amazing prizes! 🎁\n\nPlay here: ${url}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    window.open(whatsappUrl, '_blank');
  };

  const copyToClipboard = async () => {
    const url = window.location.href;
    const shareText = `🌸 Just played Leirang Leipun! Try to find the hidden bouquet and win amazing prizes! 🎁\n\nPlay here: ${url}`;
    
    try {
      await navigator.clipboard.writeText(shareText);
      toast({
        title: "Copied!",
        description: "Share link copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  if (!gameStarted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 floral-bg relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-32 h-32 bg-pink-300 rounded-full blur-3xl"></div>
          <div className="absolute top-32 right-16 w-24 h-24 bg-rose-300 rounded-full blur-2xl"></div>
          <div className="absolute bottom-16 left-1/4 w-28 h-28 bg-pink-200 rounded-full blur-3xl"></div>
          <div className="absolute bottom-32 right-10 w-20 h-20 bg-rose-200 rounded-full blur-2xl"></div>
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 w-full max-w-md border border-pink-200/50 relative z-10"
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.3, duration: 0.8, type: "spring" }}
              className="w-24 h-24 bg-gradient-to-br from-pink-400 to-rose-400 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg ring-4 ring-pink-100"
            >
              <span className="text-4xl">🌸</span>
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-3xl font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-3"
            >
              Leirang Leipun
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="text-xl text-pink-700 font-semibold mb-2"
            >
              Tap & Win a Flower!
            </motion.p>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="text-sm text-gray-600"
            >
              Join our special giveaway game
            </motion.p>
          </div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-6 mb-8 border border-pink-200"
          >
            <div className="text-center">
              <div className="flex justify-center space-x-2 mb-4">
                <span className="text-2xl">🌸</span>
                <span className="text-2xl">🎁</span>
                <span className="text-2xl">💝</span>
              </div>
              <p className="text-gray-700 leading-relaxed font-medium">
                Play our special giveaway game! Find the hidden bouquet in a 5x5 grid and win amazing prizes:
              </p>
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="bg-white rounded-lg p-3 shadow-sm">
                  <div className="text-lg">🌸</div>
                  <div className="text-xs font-semibold text-pink-600">Real Bouquet</div>
                </div>
                <div className="bg-white rounded-lg p-3 shadow-sm">
                  <div className="text-lg">🎉</div>
                  <div className="text-xs font-semibold text-blue-600">₹100 OFF</div>
                </div>
                <div className="bg-white rounded-lg p-3 shadow-sm">
                  <div className="text-lg">🎁</div>
                  <div className="text-xs font-semibold text-green-600">₹10 OFF</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Instagram Follow Step */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.0 }}
            className="mb-6"
          >
            <div className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl p-5 mb-4 shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mr-4">
                    <span className="text-2xl">📱</span>
                  </div>
                  <div>
                    <p className="font-bold text-white text-lg">Step 1: Follow Us</p>
                    <p className="text-pink-100 font-medium">@leirang_leipun</p>
                  </div>
                </div>
                <a
                  href="https://www.instagram.com/leirang_leipun?igsh=MTI1YXRvZjY1ZGx1dw=="
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white text-pink-600 px-6 py-3 rounded-xl font-bold hover:bg-pink-50 transition-all transform hover:scale-105 shadow-lg"
                >
                  Follow Now
                </a>
              </div>
              <div className="mt-3 flex items-center text-pink-100 text-sm">
                <span className="mr-2">✨</span>
                <span>Get the latest updates and exclusive offers!</span>
              </div>
            </div>
          </motion.div>

          {/* Username Input */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.2 }}
            className="mb-8"
          >
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-5 border border-blue-200">
              <label className="block text-gray-800 font-bold mb-4">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center mr-3">
                    <span className="text-lg text-white">📝</span>
                  </div>
                  <span className="text-lg">Step 2: Enter Your Instagram Username</span>
                </div>
              </label>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="your_instagram_username"
                  value={instagramUsername}
                  onChange={(e) => setInstagramUsername(e.target.value)}
                  className="w-full px-6 py-4 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none transition-all text-lg font-medium bg-white shadow-sm"
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-400 pointer-events-none">
                  @
                </div>
              </div>
              <div className="mt-3 flex items-center text-blue-600 text-sm font-medium">
                <span className="mr-2">🎯</span>
                <span>We'll verify your follow and contact you if you win!</span>
              </div>
            </div>
          </motion.div>

          {/* Start Game Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4 }}
            className="mb-4"
          >
            <Button
              onClick={startGame}
              className="w-full bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-bold py-5 rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-pink-300/50 text-lg"
            >
              <span className="flex items-center justify-center">
                <span className="mr-3 text-xl">🌸</span>
                I've Followed. Start Game!
                <span className="ml-3 text-xl">🎮</span>
              </span>
            </Button>
          </motion.div>
          
          {/* Share Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5 }}
            className="mb-4"
          >
            <Button
              onClick={() => setShowShareModal(true)}
              variant="outline"
              className="w-full border-pink-300 text-pink-600 hover:bg-pink-50 font-semibold py-3 rounded-xl transition-all duration-300"
            >
              <span className="mr-2">📤</span>
              Share with Friends
            </Button>
          </motion.div>

          {/* Admin Link */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.6 }}
            className="text-center"
          >
            <Link href="/admin">
              <span className="inline-flex items-center text-xs text-gray-400 hover:text-pink-600 transition-all duration-300 cursor-pointer hover:bg-pink-50 px-3 py-2 rounded-lg">
                <span className="mr-1">📊</span>
                Admin Dashboard
              </span>
            </Link>
          </motion.div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 bg-gradient-to-br from-cream via-pastel-pink to-light-pink floral-bg">
      <div className="max-w-md mx-auto">
        {/* Game Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Tap & Win! 🌸</h2>
            <div className="text-right">
              <p className="text-sm text-gray-600">Taps Remaining</p>
              <p className="text-2xl font-bold text-soft-pink">{gameState.tapsRemaining}</p>
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-pastel-pink/20 rounded-xl p-4 mb-4">
            <p className="text-sm text-gray-700 text-center">
              🎯 Tap one square at a time. You have 10 chances. Hit a bomb 💣 and you're out. Play wisely!
            </p>
          </div>

          {/* Prizes Info */}
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center bg-green-50 rounded-lg p-2">
              <div className="text-lg">🌸</div>
              <div className="font-medium">1 Bouquet</div>
            </div>
            <div className="text-center bg-blue-50 rounded-lg p-2">
              <div className="text-lg">🎉</div>
              <div className="font-medium">₹100 off</div>
            </div>
            <div className="text-center bg-yellow-50 rounded-lg p-2">
              <div className="text-lg">🎁</div>
              <div className="font-medium">6x ₹10 off</div>
            </div>
          </div>
        </motion.div>

        {/* Game Grid */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl shadow-lg p-6"
        >
          <div className="grid grid-cols-5 gap-3">
            {Array.from({ length: 25 }).map((_, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 * index }}
                className={`game-square bg-gradient-to-br from-soft-pink to-light-pink aspect-square rounded-xl flex items-center justify-center text-2xl cursor-pointer hover:from-light-pink hover:to-soft-pink transition-all duration-300 shadow-md ${
                  gameState.revealedSquares[index] ? 'cursor-default' : ''
                }`}
                onClick={() => handleSquareClick(index)}
                whileHover={{ scale: gameState.revealedSquares[index] ? 1 : 1.05 }}
                whileTap={{ scale: gameState.revealedSquares[index] ? 1 : 0.95 }}
              >
                {gameState.revealedSquares[index] ? gameState.gameBoard[index]?.emoji : '❓'}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Current Prizes */}
        <AnimatePresence>
          {gameState.prizes.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mt-6 bg-white rounded-2xl shadow-lg p-6"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">Your Prizes 🏆</h3>
              <div className="space-y-2">
                {gameState.prizes.map((prize, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between bg-green-50 rounded-lg p-3"
                  >
                    <span className="flex items-center">
                      <span className="text-xl mr-3">{prize.emoji}</span>
                      <span className="font-medium">{prize.text}</span>
                    </span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Reward Modal */}
      <Dialog open={showRewardModal} onOpenChange={setShowRewardModal}>
        <DialogContent className="max-w-sm mx-auto bg-white rounded-3xl shadow-2xl p-8">
          <DialogTitle className="sr-only">Reward Found</DialogTitle>
          <DialogDescription className="sr-only">
            You found a reward. Choose to keep it or continue playing.
          </DialogDescription>
          <div className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4"
            >
              <span className="text-2xl">{gameState.currentReward?.emoji}</span>
            </motion.div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">You Found a Reward!</h3>
            <p className="text-gray-600 mb-6">{gameState.currentReward?.text}</p>
            <p className="text-sm text-gray-500 mb-8">
              Do you want to keep this reward or continue playing? Remember: if you hit a bomb, you lose everything!
            </p>

            <div className="flex gap-3">
              <Button
                onClick={keepReward}
                className="flex-1 bg-green-500 text-white font-semibold py-3 rounded-xl hover:bg-green-600 transition-colors"
              >
                Keep It 🛡️
              </Button>
              <Button
                onClick={continueGame}
                className="flex-1 bg-soft-pink text-white font-semibold py-3 rounded-xl hover:bg-light-pink transition-colors"
              >
                Continue 🎲
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Result Modal */}
      <Dialog open={showResultModal} onOpenChange={setShowResultModal}>
        <DialogContent className="max-w-sm mx-auto bg-white rounded-3xl shadow-2xl p-8">
          <div className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                resultType === 'win'
                  ? 'bg-gradient-to-br from-green-400 to-emerald-500'
                  : 'bg-gradient-to-br from-red-400 to-pink-500'
              }`}
            >
              <span className="text-3xl">{resultType === 'win' ? '🎉' : '💣'}</span>
            </motion.div>
            <h3 className={`text-2xl font-bold mb-4 ${
              resultType === 'win' ? 'text-green-600' : 'text-red-600'
            }`}>
              {resultTitle}
            </h3>
            <p className="text-gray-600 mb-6">{resultMessage}</p>

            {gameState.prizes.length > 0 && (
              <div className="bg-green-50 rounded-xl p-4 mb-6">
                <h4 className="font-semibold text-green-800 mb-2">Your Prizes:</h4>
                {gameState.prizes.map((prize, index) => (
                  <div key={index} className="flex items-center mb-1">
                    <span className="mr-2">{prize.emoji}</span>
                    <span className="text-sm">{prize.text}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <Button
                onClick={() => setShowShareModal(true)}
                className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold py-4 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-300"
              >
                Share 📤
              </Button>
              <Button
                onClick={resetGame}
                className="flex-1 bg-gradient-to-r from-soft-pink to-light-pink text-white font-semibold py-4 rounded-xl hover:from-light-pink hover:to-soft-pink transition-all duration-300"
              >
                Play Again 🔄
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Play Limit Modal */}
      <Dialog open={showPlayLimitModal} onOpenChange={setShowPlayLimitModal}>
        <DialogContent className="bg-white rounded-2xl p-8 max-w-sm mx-auto">
          <div className="text-center">
            <DialogTitle className="text-2xl font-bold text-red-600 mb-4">Play Limit Reached</DialogTitle>
            <DialogDescription asChild>
              <div className="space-y-4">
                <div className="text-6xl mb-4">⏳</div>
                <p className="text-gray-700">
                  You've reached your monthly play limit of 5 games.
                </p>
                {playLimitInfo && playLimitInfo.resetDate && (
                  <p className="text-sm text-gray-600">
                    You can play again starting: <strong>{new Date(playLimitInfo.resetDate).toLocaleDateString()}</strong>
                  </p>
                )}
                <p className="text-sm text-pink-600 font-medium">
                  Share the game with friends while you wait!
                </p>
                <div className="flex gap-2 mt-6">
                  <Button
                    onClick={() => {
                      setShowPlayLimitModal(false);
                      setShowShareModal(true);
                    }}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold py-3 rounded-xl"
                  >
                    Share Game 📤
                  </Button>
                  <Button
                    onClick={() => setShowPlayLimitModal(false)}
                    variant="outline"
                    className="flex-1 py-3 rounded-xl"
                  >
                    Close
                  </Button>
                </div>
              </div>
            </DialogDescription>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Modal */}
      <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
        <DialogContent className="bg-white rounded-2xl p-8 max-w-sm mx-auto">
          <div className="text-center">
            <DialogTitle className="text-2xl font-bold text-pink-600 mb-4">Share Leirang Leipun</DialogTitle>
            <DialogDescription asChild>
              <div className="space-y-4">
                <div className="text-6xl mb-4">🌸</div>
                <p className="text-gray-700 text-sm">
                  Spread the joy! Share this amazing game with your friends and family.
                </p>
                
                <div className="grid grid-cols-2 gap-3 mt-6">
                  <Button
                    onClick={shareOnFacebook}
                    className="bg-[#1877F2] text-white py-3 rounded-xl hover:bg-[#166FE5] transition-all duration-300"
                  >
                    <span className="mr-2">📘</span>
                    Facebook
                  </Button>
                  <Button
                    onClick={shareOnTwitter}
                    className="bg-[#1DA1F2] text-white py-3 rounded-xl hover:bg-[#1A91DA] transition-all duration-300"
                  >
                    <span className="mr-2">🐦</span>
                    Twitter
                  </Button>
                  <Button
                    onClick={shareOnWhatsApp}
                    className="bg-[#25D366] text-white py-3 rounded-xl hover:bg-[#22C55E] transition-all duration-300"
                  >
                    <span className="mr-2">💬</span>
                    WhatsApp
                  </Button>
                  <Button
                    onClick={copyToClipboard}
                    className="bg-gray-600 text-white py-3 rounded-xl hover:bg-gray-700 transition-all duration-300"
                  >
                    <span className="mr-2">📋</span>
                    Copy Link
                  </Button>
                </div>
                
                <Button
                  onClick={() => setShowShareModal(false)}
                  variant="outline"
                  className="w-full mt-4 py-3 rounded-xl"
                >
                  Close
                </Button>
              </div>
            </DialogDescription>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
