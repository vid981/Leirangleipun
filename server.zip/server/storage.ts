import { users, gameParticipants, userPlayLimits, type User, type InsertUser, type GameParticipant, type InsertGameParticipant, type UserPlayLimit, type InsertUserPlayLimit } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createGameParticipant(participant: InsertGameParticipant): Promise<GameParticipant>;
  getGameParticipants(): Promise<GameParticipant[]>;
  getGameParticipantByInstagramUsername(username: string): Promise<GameParticipant[]>;
  // Play limit methods
  getUserPlayLimit(instagramUsername: string): Promise<UserPlayLimit | undefined>;
  updateUserPlayLimit(instagramUsername: string, currentMonth: string): Promise<UserPlayLimit>;
  canUserPlay(instagramUsername: string): Promise<{ canPlay: boolean; playsRemaining: number; resetDate?: string }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createGameParticipant(insertParticipant: InsertGameParticipant): Promise<GameParticipant> {
    const [participant] = await db
      .insert(gameParticipants)
      .values(insertParticipant)
      .returning();
    return participant;
  }

  async getGameParticipants(): Promise<GameParticipant[]> {
    return await db.select().from(gameParticipants).orderBy(gameParticipants.playedAt);
  }

  async getGameParticipantByInstagramUsername(username: string): Promise<GameParticipant[]> {
    return await db.select().from(gameParticipants).where(eq(gameParticipants.instagramUsername, username));
  }

  async getUserPlayLimit(instagramUsername: string): Promise<UserPlayLimit | undefined> {
    const [playLimit] = await db.select().from(userPlayLimits).where(eq(userPlayLimits.instagramUsername, instagramUsername));
    return playLimit || undefined;
  }

  async updateUserPlayLimit(instagramUsername: string, currentMonth: string): Promise<UserPlayLimit> {
    const existingLimit = await this.getUserPlayLimit(instagramUsername);
    
    if (!existingLimit) {
      // Create new record
      const [newLimit] = await db
        .insert(userPlayLimits)
        .values({
          instagramUsername,
          playsThisMonth: 1,
          lastPlayMonth: currentMonth,
        })
        .returning();
      return newLimit;
    } else {
      // Update existing record
      const isNewMonth = existingLimit.lastPlayMonth !== currentMonth;
      const newPlaysCount = isNewMonth ? 1 : existingLimit.playsThisMonth + 1;
      
      const [updatedLimit] = await db
        .update(userPlayLimits)
        .set({
          playsThisMonth: newPlaysCount,
          lastPlayMonth: currentMonth,
          updatedAt: new Date(),
        })
        .where(eq(userPlayLimits.instagramUsername, instagramUsername))
        .returning();
      return updatedLimit;
    }
  }

  async canUserPlay(instagramUsername: string): Promise<{ canPlay: boolean; playsRemaining: number; resetDate?: string }> {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
    const playLimit = await this.getUserPlayLimit(instagramUsername);
    
    if (!playLimit) {
      // New user, can play
      return { canPlay: true, playsRemaining: 5 };
    }
    
    // Check if it's a new month
    if (playLimit.lastPlayMonth !== currentMonth) {
      // New month, reset count
      return { canPlay: true, playsRemaining: 5 };
    }
    
    // Same month, check play count
    const playsRemaining = Math.max(0, 5 - playLimit.playsThisMonth);
    const canPlay = playsRemaining > 0;
    
    // Calculate next reset date (first day of next month)
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    nextMonth.setDate(1);
    const resetDate = nextMonth.toISOString().slice(0, 10); // YYYY-MM-DD format
    
    return { 
      canPlay, 
      playsRemaining,
      resetDate: !canPlay ? resetDate : undefined
    };
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private gameParticipants: Map<number, GameParticipant>;
  private userPlayLimits: Map<string, UserPlayLimit>;
  private currentUserId: number;
  private currentParticipantId: number;
  private currentPlayLimitId: number;

  constructor() {
    this.users = new Map();
    this.gameParticipants = new Map();
    this.userPlayLimits = new Map();
    this.currentUserId = 1;
    this.currentParticipantId = 1;
    this.currentPlayLimitId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createGameParticipant(insertParticipant: InsertGameParticipant): Promise<GameParticipant> {
    const id = this.currentParticipantId++;
    const participant: GameParticipant = { 
      ...insertParticipant, 
      id,
      playedAt: new Date()
    };
    this.gameParticipants.set(id, participant);
    return participant;
  }

  async getGameParticipants(): Promise<GameParticipant[]> {
    return Array.from(this.gameParticipants.values());
  }

  async getGameParticipantByInstagramUsername(username: string): Promise<GameParticipant[]> {
    return Array.from(this.gameParticipants.values()).filter(
      (participant) => participant.instagramUsername === username
    );
  }

  async getUserPlayLimit(instagramUsername: string): Promise<UserPlayLimit | undefined> {
    return this.userPlayLimits.get(instagramUsername);
  }

  async updateUserPlayLimit(instagramUsername: string, currentMonth: string): Promise<UserPlayLimit> {
    const existingLimit = this.userPlayLimits.get(instagramUsername);
    
    if (!existingLimit) {
      // Create new record
      const newLimit: UserPlayLimit = {
        id: this.currentPlayLimitId++,
        instagramUsername,
        playsThisMonth: 1,
        lastPlayMonth: currentMonth,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.userPlayLimits.set(instagramUsername, newLimit);
      return newLimit;
    } else {
      // Update existing record
      const isNewMonth = existingLimit.lastPlayMonth !== currentMonth;
      const newPlaysCount = isNewMonth ? 1 : existingLimit.playsThisMonth + 1;
      
      const updatedLimit: UserPlayLimit = {
        ...existingLimit,
        playsThisMonth: newPlaysCount,
        lastPlayMonth: currentMonth,
        updatedAt: new Date(),
      };
      this.userPlayLimits.set(instagramUsername, updatedLimit);
      return updatedLimit;
    }
  }

  async canUserPlay(instagramUsername: string): Promise<{ canPlay: boolean; playsRemaining: number; resetDate?: string }> {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
    const playLimit = this.userPlayLimits.get(instagramUsername);
    
    if (!playLimit) {
      // New user, can play
      return { canPlay: true, playsRemaining: 5 };
    }
    
    // Check if it's a new month
    if (playLimit.lastPlayMonth !== currentMonth) {
      // New month, reset count
      return { canPlay: true, playsRemaining: 5 };
    }
    
    // Same month, check play count
    const playsRemaining = Math.max(0, 5 - playLimit.playsThisMonth);
    const canPlay = playsRemaining > 0;
    
    // Calculate next reset date (first day of next month)
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    nextMonth.setDate(1);
    const resetDate = nextMonth.toISOString().slice(0, 10); // YYYY-MM-DD format
    
    return { 
      canPlay, 
      playsRemaining,
      resetDate: !canPlay ? resetDate : undefined
    };
  }
}

export const storage = new DatabaseStorage();
