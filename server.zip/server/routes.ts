import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameParticipantSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Check if user can play the game
  app.get("/api/can-play/:username", async (req, res) => {
    try {
      const { username } = req.params;
      const playStatus = await storage.canUserPlay(username);
      res.json({ success: true, ...playStatus });
    } catch (error) {
      res.status(500).json({ success: false, error: "Failed to check play status" });
    }
  });

  // Submit game result
  app.post("/api/game-result", async (req, res) => {
    try {
      const gameData = insertGameParticipantSchema.parse(req.body);
      
      // Check play limit before saving
      const playStatus = await storage.canUserPlay(gameData.instagramUsername);
      if (!playStatus.canPlay) {
        return res.status(429).json({ 
          success: false, 
          error: "Play limit exceeded", 
          playsRemaining: playStatus.playsRemaining,
          resetDate: playStatus.resetDate
        });
      }
      
      // Save game result
      const result = await storage.createGameParticipant(gameData);
      
      // Update play count
      const currentMonth = new Date().toISOString().slice(0, 7);
      await storage.updateUserPlayLimit(gameData.instagramUsername, currentMonth);
      
      res.json({ success: true, result });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ success: false, error: "Invalid game data", details: error.errors });
      } else {
        res.status(500).json({ success: false, error: "Failed to save game result" });
      }
    }
  });

  // Get all game participants (for admin purposes)
  app.get("/api/game-participants", async (req, res) => {
    try {
      const participants = await storage.getGameParticipants();
      res.json({ success: true, participants });
    } catch (error) {
      res.status(500).json({ success: false, error: "Failed to fetch participants" });
    }
  });

  // Get participants by Instagram username
  app.get("/api/game-participants/:username", async (req, res) => {
    try {
      const { username } = req.params;
      const participants = await storage.getGameParticipantByInstagramUsername(username);
      res.json({ success: true, participants });
    } catch (error) {
      res.status(500).json({ success: false, error: "Failed to fetch participant data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
