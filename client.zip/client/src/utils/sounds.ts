// Sound effects utility for the game
class SoundManager {
  private context: AudioContext | null = null;
  private enabled = true;

  constructor() {
    // Initialize AudioContext on first user interaction
    this.initializeAudio();
  }

  private initializeAudio() {
    try {
      this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.warn('Audio not supported in this browser');
      this.enabled = false;
    }
  }

  private async resumeContext() {
    if (this.context && this.context.state === 'suspended') {
      await this.context.resume();
    }
  }

  // Generate different tones for different interactions
  private generateTone(frequency: number, duration: number, type: OscillatorType = 'sine') {
    if (!this.enabled || !this.context) return;

    this.resumeContext();

    const oscillator = this.context.createOscillator();
    const gainNode = this.context.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.context.destination);

    oscillator.frequency.setValueAtTime(frequency, this.context.currentTime);
    oscillator.type = type;

    // Envelope for smooth sound
    gainNode.gain.setValueAtTime(0, this.context.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.1, this.context.currentTime + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.context.currentTime + duration);

    oscillator.start(this.context.currentTime);
    oscillator.stop(this.context.currentTime + duration);
  }

  // Different sound effects for different game events
  playTap() {
    // Light tap sound - short and gentle
    this.generateTone(800, 0.1, 'triangle');
  }

  playReveal() {
    // Reveal sound - slightly longer with a pleasant tone
    this.generateTone(600, 0.15, 'sine');
  }

  playPrizeFound() {
    // Success sound - ascending tones
    setTimeout(() => this.generateTone(523, 0.1, 'triangle'), 0);   // C
    setTimeout(() => this.generateTone(659, 0.1, 'triangle'), 100); // E
    setTimeout(() => this.generateTone(784, 0.2, 'triangle'), 200); // G
  }

  playBombHit() {
    // Bomb sound - descending dramatic tones
    setTimeout(() => this.generateTone(400, 0.1, 'sawtooth'), 0);
    setTimeout(() => this.generateTone(300, 0.1, 'sawtooth'), 100);
    setTimeout(() => this.generateTone(200, 0.3, 'sawtooth'), 200);
  }

  playBouquetWin() {
    // Victory fanfare - multiple ascending tones
    const notes = [523, 659, 784, 1047]; // C, E, G, C (octave)
    notes.forEach((freq, index) => {
      setTimeout(() => this.generateTone(freq, 0.3, 'triangle'), index * 150);
    });
  }

  playButtonHover() {
    // Subtle hover sound
    this.generateTone(1000, 0.05, 'sine');
  }

  playButtonClick() {
    // Button click sound
    this.generateTone(1200, 0.1, 'triangle');
  }

  // Enable/disable sounds
  setEnabled(enabled: boolean) {
    this.enabled = enabled;
  }

  isEnabled() {
    return this.enabled;
  }
}

// Export singleton instance
export const soundManager = new SoundManager();