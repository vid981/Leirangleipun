import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { GameParticipant } from "@shared/schema";

export default function Admin() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: participantsData, isLoading, refetch } = useQuery({
    queryKey: ["/api/game-participants"],
  });

  const participants = (participantsData as any)?.participants || [];

  // Filter participants based on search query
  const filteredParticipants = participants.filter((participant: GameParticipant) =>
    participant.instagramUsername.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Calculate statistics
  const totalParticipants = participants.length;
  const winners = participants.filter((p: GameParticipant) => p.gameResult === 'win');
  const losers = participants.filter((p: GameParticipant) => p.gameResult === 'lose');
  const winRate = totalParticipants > 0 ? ((winners.length / totalParticipants) * 100).toFixed(1) : 0;

  // Prize statistics
  const prizeStats = participants.reduce((acc: Record<string, number>, participant: GameParticipant) => {
    if (participant.gameResult === 'win') {
      try {
        const prizes = JSON.parse(participant.prizesWon);
        prizes.forEach((prize: any) => {
          const key = prize.type;
          acc[key] = (acc[key] || 0) + 1;
        });
      } catch (e) {
        // Handle invalid JSON
      }
    }
    return acc;
  }, {});

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatPrizes = (prizesWonString: string) => {
    try {
      const prizes = JSON.parse(prizesWonString);
      return prizes.map((prize: any, index: number) => (
        <Badge key={index} variant="secondary" className="mr-1 mb-1">
          {prize.emoji} {prize.text}
        </Badge>
      ));
    } catch (e) {
      return <Badge variant="outline">No valid prizes</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cream via-pastel-pink to-light-pink">
        <div className="text-center">
          <div className="w-16 h-16 bg-soft-pink rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <span className="text-2xl"></span>
          </div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream via-pastel-pink to-light-pink p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
              <p className="text-gray-600">Leirang Leipun Giveaway - Game Analytics</p>
            </div>
            <Button 
              onClick={() => refetch()}
              className="bg-soft-pink hover:bg-light-pink text-white"
            >
              Refresh Data 🔄
            </Button>
          </div>
        </motion.div>

        {/* Statistics Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6"
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Players</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-800">{totalParticipants}</div>
              <p className="text-xs text-gray-500 mt-1">All time participants</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Winners</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{winners.length}</div>
              <p className="text-xs text-gray-500 mt-1">Win rate: {winRate}%</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Game Over</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{losers.length}</div>
              <p className="text-xs text-gray-500 mt-1">Hit bombs</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Bouquets Won</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-pink-600">{prizeStats.bouquet || 0}</div>
              <p className="text-xs text-gray-500 mt-1">Grand prizes</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Tabs for different views */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="participants" className="bg-white rounded-2xl shadow-lg p-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="participants">All Participants</TabsTrigger>
              <TabsTrigger value="winners">Winners Only</TabsTrigger>
              <TabsTrigger value="prizes">Prize Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="participants" className="mt-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Input
                    placeholder="Search by Instagram username..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="max-w-md"
                  />
                  <Badge variant="outline">
                    {filteredParticipants.length} of {totalParticipants} shown
                  </Badge>
                </div>

                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Instagram</TableHead>
                        <TableHead>Result</TableHead>
                        <TableHead>Prizes Won</TableHead>
                        <TableHead>Taps Used</TableHead>
                        <TableHead>Date Played</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredParticipants.map((participant: GameParticipant) => (
                        <TableRow key={participant.id}>
                          <TableCell className="font-medium">
                            <a
                              href={`https://instagram.com/${participant.instagramUsername}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              @{participant.instagramUsername}
                            </a>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={participant.gameResult === 'win' ? 'default' : 'destructive'}
                              className={participant.gameResult === 'win' ? 'bg-green-500' : ''}
                            >
                              {participant.gameResult === 'win' ? '🎉 Won' : '💣 Lost'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {participant.gameResult === 'win' ? formatPrizes(participant.prizesWon) : '-'}
                            </div>
                          </TableCell>
                          <TableCell>{participant.tapsUsed}/10</TableCell>
                          <TableCell className="text-sm text-gray-500">
                            {formatDate(participant.playedAt.toString())}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="winners" className="mt-6">
              <div className="space-y-4">
                <Badge variant="outline" className="mb-4">
                  {winners.length} winners found
                </Badge>

                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Instagram</TableHead>
                        <TableHead>Prizes Won</TableHead>
                        <TableHead>Taps Used</TableHead>
                        <TableHead>Date Won</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {winners.map((participant: GameParticipant) => (
                        <TableRow key={participant.id}>
                          <TableCell className="font-medium">
                            <a
                              href={`https://instagram.com/${participant.instagramUsername}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              @{participant.instagramUsername}
                            </a>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {formatPrizes(participant.prizesWon)}
                            </div>
                          </TableCell>
                          <TableCell>{participant.tapsUsed}/10</TableCell>
                          <TableCell className="text-sm text-gray-500">
                            {formatDate(participant.playedAt.toString())}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="prizes" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <span>🌸</span>
                      <span>Bouquets</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-pink-600">{prizeStats.bouquet || 0}</div>
                    <p className="text-sm text-gray-500">Grand prizes won</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <span>🎉</span>
                      <span>₹100 Coupons</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600">{prizeStats.coupon100 || 0}</div>
                    <p className="text-sm text-gray-500">High value coupons</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <span>🎁</span>
                      <span>₹10 Coupons</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">{prizeStats.coupon10 || 0}</div>
                    <p className="text-sm text-gray-500">Small value coupons</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}