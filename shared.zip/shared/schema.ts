import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const gameParticipants = pgTable("game_participants", {
  id: serial("id").primaryKey(),
  instagramUsername: text("instagram_username").notNull(),
  gameResult: text("game_result").notNull(), // 'win' or 'lose'
  prizesWon: text("prizes_won").notNull(), // JSON string of prizes array
  tapsUsed: integer("taps_used").notNull(),
  playedAt: timestamp("played_at").defaultNow().notNull(),
});

// New table to track user play counts and cooldowns
export const userPlayLimits = pgTable("user_play_limits", {
  id: serial("id").primaryKey(),
  instagramUsername: text("instagram_username").notNull().unique(),
  playsThisMonth: integer("plays_this_month").notNull().default(0),
  lastPlayMonth: text("last_play_month").notNull(), // Format: YYYY-MM
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGameParticipantSchema = createInsertSchema(gameParticipants).pick({
  instagramUsername: true,
  gameResult: true,
  prizesWon: true,
  tapsUsed: true,
});

export const insertUserPlayLimitSchema = createInsertSchema(userPlayLimits).pick({
  instagramUsername: true,
  playsThisMonth: true,
  lastPlayMonth: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGameParticipant = z.infer<typeof insertGameParticipantSchema>;
export type GameParticipant = typeof gameParticipants.$inferSelect;
export type UserPlayLimit = typeof userPlayLimits.$inferSelect;
export type InsertUserPlayLimit = z.infer<typeof insertUserPlayLimitSchema>;
